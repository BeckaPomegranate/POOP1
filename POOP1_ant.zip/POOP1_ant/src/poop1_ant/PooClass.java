/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poop1_ant;

/**
 *
 * @author estudiante
 */
public class PooClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Hello World");
        // TODO code application logic here
        
        int a = 3;
        float b = 3.5f;
        float c = a + b;
        System.out.println (c);
        double e= 7.4;
        System.out.println(e);
    }
    
}
